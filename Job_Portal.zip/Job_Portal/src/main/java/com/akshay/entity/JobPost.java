package com.akshay.entity;

import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;


@Entity
public class JobPost {

	
	@Id
	@Column
	private int postId;
	@Column
	private String postProfile;
	@Column
	private String postDesc;
	@Column
	private Integer reqExperience;
	@Column
	private List<String> postTechStack;
	
	public int getPostId() {
	return postId;
}
public void setPostId(int postId) {
	this.postId = postId;
}
public String getPostProfile() {
	return postProfile;
}
public void setPostProfile(String postProfile) {
	this.postProfile = postProfile;
}
public String getPostDesc() {
	return postDesc;
}
public void setPostDesc(String postDesc) {
	this.postDesc = postDesc;
}
public Integer getReqExperience() {
	return reqExperience;
}
public void setReqExperience(Integer reqExperience) {
	this.reqExperience = reqExperience;
}
public List<String> getPostTechStack() {
	return postTechStack;
}
public void setPostTechStack(List<String> postTechStack) {
	this.postTechStack = postTechStack;
}

	@Override
public String toString() {
	return "JobPost [postId=" + postId + ", postProfile=" + postProfile + ", postDesc=" + postDesc + ", reqExperience="
			+ reqExperience + ", postTechStack=" + postTechStack + "]";
}
	public JobPost() {
		super();
	}
	public JobPost(int postId, String postProfile, String postDesc, Integer reqExperience, List<String> postTechStack) {
		super();
		this.postId = postId;
		this.postProfile = postProfile;
		this.postDesc = postDesc;
		this.reqExperience = reqExperience;
		this.postTechStack = postTechStack;
	}
	
	

}